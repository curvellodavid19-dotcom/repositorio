# Nexo Criative - Agência de Criação de Sites

Projeto profissional de alto padrão e alta conversão para a agência **Nexo Criative**.

- **Marca:** Nexo Criative
- **Tagline:** "Seu concorrente já tem site. E você?"
- **WhatsApp:** +55 (21) 98956-4215
- **Instagram:** @nexocriativeoficial
- **Tecnologias:** React 19, TypeScript, Vite, Tailwind CSS, Lucide Icons

---

## 🚀 Como Executar Localmente

1. Instale as dependências:
```bash
npm install
```

2. Inicie o servidor de desenvolvimento:
```bash
npm run dev
```

3. Abra o navegador em:
```
http://localhost:3000
```

---

## 📦 Como Usar no Lovable

1. No [Lovable](https://lovable.dev), crie um novo projeto ou importe este repositório/pasta descompactada.
2. Todas as dependências necessárias já estão configuradas no `package.json`.
3. Os estilos, cores semânticas (#0A0A0A com dourado #D4AF37) e fontes estão configurados no `index.html` e `src/index.css`.
4. Todas as imagens em alta resolução estão preservadas em `src/assets/images/`.

---

## 🛠️ Scripts Disponíveis

- `npm run dev`: Inicia o servidor de desenvolvimento.
- `npm run build`: Gera o pacote otimizado de produção na pasta `dist/`.
- `npm run lint`: Valida tipos com TypeScript (`tsc --noEmit`).
- `npm run test`: Executa os testes unitários das regras de negócio.
