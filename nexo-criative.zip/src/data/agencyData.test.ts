import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { BRAND_CONFIG, getWhatsAppUrl, SERVICES, DIFFERENTIALS, PORTFOLIO } from './agencyData.ts';

describe('Agency Configuration & Business Logic', () => {
  test('brand identity matches Nexo Criative requirements', () => {
    assert.strictEqual(BRAND_CONFIG.name, 'Nexo Criative');
    assert.strictEqual(BRAND_CONFIG.tagline, 'Seu concorrente já tem site. E você?');
    assert.strictEqual(BRAND_CONFIG.whatsappNumber, '5521989564215');
    assert.strictEqual(BRAND_CONFIG.instagramHandle, '@nexocriativeoficial');
    assert.match(BRAND_CONFIG.aboutText, /Nexo Criative é uma agência digital/);
  });

  test('getWhatsAppUrl generates valid wa.me URLs with encoded message', () => {
    const defaultUrl = getWhatsAppUrl();
    assert.ok(defaultUrl.startsWith('https://wa.me/5521989564215?text='));
    
    const customMsg = 'Quero um site express hoje!';
    const customUrl = getWhatsAppUrl(customMsg);
    assert.ok(customUrl.includes(encodeURIComponent(customMsg)));
  });

  test('differentials include same-day delivery and humanized service', () => {
    const diffTitles = DIFFERENTIALS.map(d => d.title.toLowerCase());
    assert.ok(diffTitles.some(t => t.includes('mesmo dia')));
    assert.ok(diffTitles.some(t => t.includes('humanizado')));
  });

  test('services contain web design packages with delivery guarantees', () => {
    assert.ok(SERVICES.length >= 3);
    const expressService = SERVICES.find(s => s.id === 'site-express-mesmo-dia');
    assert.ok(expressService, 'Express same-day service must exist');
    assert.match(expressService!.deliveryTime, /mesmo dia/i);
  });

  test('portfolio items contain valid image assets and conversion metrics', () => {
    assert.ok(PORTFOLIO.length >= 3);
    PORTFOLIO.forEach(p => {
      assert.ok(p.title.length > 0);
      assert.ok(p.image.startsWith('/src/assets/images/'));
      assert.ok(p.metric.length > 0);
    });
  });
});
