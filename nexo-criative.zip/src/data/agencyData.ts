import { ServiceItem, PortfolioItem, TestimonialItem, FaqItem } from '../types.ts';

export const BRAND_CONFIG = {
  name: 'Nexo Criative',
  tagline: 'Seu concorrente já tem site. E você?',
  whatsappNumber: '5521989564215',
  whatsappDisplay: '+55 (21) 98956-4215',
  instagramHandle: '@nexocriativeoficial',
  instagramUrl: 'https://instagram.com/nexocriativeoficial',
  cityRegion: 'Atendimento Nacional • Brasil',
  targetAudience: 'Empresas que querem aumentar seu faturamento',
  aboutText:
    'A Nexo Criative é uma agência digital especializada na criação de sites profissionais, modernos e personalizados para empresas, empreendedores e profissionais de todos os segmentos. Unimos criatividade, tecnologia e estratégia para desenvolver soluções digitais que fortalecem marcas, aumentam a visibilidade e conectam negócios aos seus clientes. Nosso objetivo é transformar ideias em experiências digitais, oferecendo qualidade, inovação e projetos que valorizam cada negócio no ambiente online.',
};

export function getWhatsAppUrl(customMessage?: string): string {
  const baseText = customMessage || 'Olá, Nexo Criative! Vim pelo site e gostaria de solicitar um orçamento para o meu negócio.';
  return `https://wa.me/${BRAND_CONFIG.whatsappNumber}?text=${encodeURIComponent(baseText)}`;
}

export const DIFFERENTIALS = [
  {
    id: 'fast-delivery',
    title: 'Entrega no Mesmo Dia',
    badge: 'Diferencial Exclusivo',
    description: 'Precisa colocar sua empresa para vender ainda hoje? Desenvolvemos e publicamos sua página express em até 24 horas.',
  },
  {
    id: 'humanized-service',
    title: 'Atendimento Humanizado',
    badge: '100% Consultivo',
    description: 'Sem respostas automáticas frias ou robôs. Você fala diretamente com o estrategista que projeta seu site do início ao fim.',
  },
  {
    id: 'high-conversion',
    title: 'Foco Total em Faturamento',
    badge: 'Arquitetura de Vendas',
    description: 'Estrutura psicológica de alta conversão, botões estratégicos para WhatsApp e copywriting persuasivo para fechar contratos.',
  },
  {
    id: 'lightning-speed',
    title: 'Velocidade Ultrarrápida',
    badge: 'PageSpeed 95+',
    description: 'Seu site carrega em menos de 1 segundo em qualquer celular ou conexão, garantindo que nenhum cliente desista antes de ver.',
  },
];

export const SERVICES: ServiceItem[] = [
  {
    id: 'landing-page-conversao',
    title: 'Landing Page de Alta Conversão',
    subtitle: 'Máxima geração de leads e vendas imediatas',
    description: 'Página única focada em um único objetivo: transformar visitantes em mensagens no seu WhatsApp e pedidos de orçamento.',
    deliverables: [
      'Copywriting persuasivo orientado a vendas',
      'Integração direta com WhatsApp e Pixel de Anúncios',
      'Design responsivo para celular e computador',
      'Velocidade ultrarrápida (carregamento < 1s)',
      'Otimização básica para Google (SEO local)',
    ],
    deliveryTime: 'Opção de entrega no mesmo dia',
    isPopular: true,
    idealFor: 'Empresas e profissionais liberais que investem em tráfego pago ou querem vender já.',
    whatsappPreset: 'Olá Nexo Criative! Quero solicitar um orçamento para uma Landing Page de Alta Conversão.',
  },
  {
    id: 'site-institucional-elite',
    title: 'Site Institucional Corporativo',
    subtitle: 'Autoridade máxima para empresas consolidadas',
    description: 'Presença digital sofisticada para empresas que precisam transmitir credibilidade, fechar contratos maiores e valorizar a marca.',
    deliverables: [
      'Estrutura multipáginas (Início, Quem Somos, Serviços, Contato)',
      'Apresentação de portfólio e equipe',
      'Formulários integrados com WhatsApp e e-mail corporativo',
      'Painel de gerenciamento intuitivo e moderno',
      'Indexação completa nas buscas do Google',
    ],
    deliveryTime: '3 a 7 dias úteis',
    idealFor: 'Clínicas, escritórios jurídicos, construtoras, indústrias e empresas B2B.',
    whatsappPreset: 'Olá Nexo Criative! Gostaria de um orçamento para um Site Institucional Completo.',
  },
  {
    id: 'site-express-mesmo-dia',
    title: 'Site Express 24h (Mesmo Dia)',
    subtitle: 'Lançamento imediato para quem não pode esperar',
    description: 'Ideal para lançamentos relâmpago, eventos, promoções especiais ou empresas que precisam estar online no ar ainda hoje.',
    deliverables: [
      'Desenvolvimento prioritário dedicado no mesmo dia',
      'Estrutura One-Page direta com botão flutuante WhatsApp',
      'Publicação e configuração do domínio no ar',
      'Atendimento em tempo real via WhatsApp',
    ],
    deliveryTime: 'No mesmo dia (24h)',
    idealFor: 'Negócios com urgência máxima para rodar campanhas ou atender clientes hoje.',
    whatsappPreset: 'Olá Nexo Criative! Preciso de um Site Express com entrega no mesmo dia (urgente)!',
  },
  {
    id: 'ecommerce-loja-virtual',
    title: 'E-commerce & Catálogo Digital',
    subtitle: 'Venda produtos 24 horas por dia de forma automática',
    description: 'Loja virtual moderna e segura, com checkout simplificado, cálculo de frete automático e integração de pagamentos Pix e Cartão.',
    deliverables: [
      'Catálogo de produtos com fotos em alta definição',
      'Checkout otimizado sem fricção',
      'Integração com Mercado Pago, Asaas ou PagSeguro',
      'Cálculo automático de frete e rastreamento',
      'Painel simples de gestão de pedidos e estoque',
    ],
    deliveryTime: '7 a 15 dias úteis',
    idealFor: 'Lojas de moda, cosméticos, suplementos, artesanato e comércio em geral.',
    whatsappPreset: 'Olá Nexo Criative! Gostaria de um orçamento para E-commerce / Loja Virtual.',
  },
];

export const PORTFOLIO: PortfolioItem[] = [
  {
    id: 'aethelred-advocacia',
    title: 'Aethelred & Vane Sociedade de Advogados',
    client: 'Escritório de Advocacia Corporativa',
    category: 'Institucional',
    image: '/src/assets/images/portfolio_advocacia_elite_1794197677843.jpg',
    metric: '+280%',
    metricLabel: 'Aumento em consultas qualificadas',
    description: 'Desenvolvimento de portal institucional de alto padrão para banca jurídica empresarial. O design com tons pretos e dourados transmitiu autoridade imediata para clientes corporativos.',
    technologies: ['Design Sob Medida', 'SEO Jurídico', 'WhatsApp Direto', 'Responsivo'],
    features: ['Agendamento de reuniões online', 'Apresentação de sócios e áreas de atuação', 'Conformidade com OAB'],
  },
  {
    id: 'aura-dermatologia',
    title: 'Clínica Aura Dermatologia & Estética',
    client: 'Clínica Médica de Alto Padrão',
    category: 'Landing Page',
    image: '/src/assets/images/portfolio_clinica_estetica_1794197679053.jpg',
    metric: '+340%',
    metricLabel: 'Captação de pacientes particulares',
    description: 'Landing page projetada para tratamentos estéticos avançados e procedimentos faciais. Foco em experiência sensorial, prova social de pacientes e agendamento direto pelo WhatsApp.',
    technologies: ['Landing Page Conversiva', 'Carregamento 0.6s', 'WhatsApp Integrado'],
    features: ['Galeria de procedimentos', 'Depoimentos em vídeo e texto', 'Botão flutuante de triagem'],
  },
  {
    id: 'aurora-residencias',
    title: 'Aurora Grand Penthouses & Imóveis',
    client: 'Imobiliária & Construtora Boutique',
    category: 'Institucional',
    image: '/src/assets/images/portfolio_imoveis_luxo_1794197679264.jpg',
    metric: 'R$ 4.2M',
    metricLabel: 'Em vendas de imóveis atribuídas ao site',
    description: 'Vitrine digital para coberturas e residências de luxo. Interface fluida com fotos arquitetônicas em tela cheia e formulário para investidores nacionais e internacionais.',
    technologies: ['Catálogo de Imóveis', 'Visualização em Alta Definição', 'Lead Scoring'],
    features: ['Tour fotográfico imersivo', 'Filtro por metragem e valor', 'Atendimento privativo WhatsApp'],
  },
  {
    id: 'nexo-showcase-express',
    title: 'Nexo Performance Showcase',
    client: 'Empresas Diversas com Entrega Express',
    category: 'Express 24h',
    image: '/src/assets/images/hero_agency_showcase_1794197678116.jpg',
    metric: '24 Horas',
    metricLabel: 'Do briefing à publicação no ar',
    description: 'Exemplo prático do nosso modelo de entrega no mesmo dia: criação de estrutura ágil, redação persuasiva e conexão com o WhatsApp do cliente para iniciar vendas no mesmo dia.',
    technologies: ['Fast Track 24h', 'Arquitetura Conversiva', 'Pronto para Tráfego Pago'],
    features: ['Publicação imediata', 'Copywriting orientado a fechamento', 'Garantia de satisfação'],
  },
];

export const TESTIMONIALS: TestimonialItem[] = [
  {
    id: 'dep-1',
    name: 'Dr. Leonardo Castanheira',
    role: 'Sócio Fundador',
    company: 'Castanheira & Associados Advocacia',
    city: 'Rio de Janeiro / RJ',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&h=150&q=80',
    content:
      'Estávamos há mais de 2 anos com um site desatualizado que não gerava contatos. A Nexo Criative reformulou toda a nossa identidade digital com um padrão preto e dourado impecável. Na primeira semana com o site novo no ar, fechamos 3 contratos de honorários corporativos.',
    metric: '+320% de contatos qualificados',
    serviceUsed: 'Site Institucional Corporativo',
  },
  {
    id: 'dep-2',
    name: 'Dra. Mariana Vasconcellos',
    role: 'Diretora Clínica',
    company: 'Instituto Vasconcellos de Estética',
    city: 'São Paulo / SP',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=150&h=150&q=80',
    content:
      'O atendimento humanizado fez toda a diferença. O desenvolvedor me ouviu com paciência e entendeu exatamente o público exigente da minha clínica. O site passa uma sofisticação surreal e os pacientes elogiam antes mesmo da consulta.',
    metric: 'Agenda lotada para 45 dias',
    serviceUsed: 'Landing Page de Alta Conversão',
  },
  {
    id: 'dep-3',
    name: 'Rodrigo Medeiros',
    role: 'CEO & Fundador',
    company: 'Medeiros Logística & Distribuição',
    city: 'Curitiba / PR',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&h=150&q=80',
    content:
      'Tínhamos uma proposta comercial gigantesca para apresentar e precisávamos de um site no ar com urgência. A Nexo Criative entregou no mesmo dia com qualidade de agência multinacional. Fechamos uma conta de 6 dígitos que citou o nosso site como ponto de confiança.',
    metric: 'Entrega em menos de 24 horas',
    serviceUsed: 'Site Express 24h (Mesmo Dia)',
  },
];

export const FAQS: FaqItem[] = [
  {
    question: 'Como funciona a Entrega no Mesmo Dia?',
    answer:
      'Nosso serviço Express é ideal para empresas com urgência. Você nos envia as informações básicas do seu negócio pelo WhatsApp pela manhã, e nossa equipe foca exclusivamente no seu projeto durante o dia. Até o final do dia, seu site está no ar, configurado e pronto para receber clientes.',
  },
  {
    question: 'O que significa o atendimento ser "humanizado"?',
    answer:
      'Significa que você não fala com chatbots nem passa por atendentes que não entendem de design e tecnologia. Você conversa diretamente com o profissional responsável pela criação e estratégia do seu site, recebendo orientação prática sobre o que mais converte no seu nicho.',
  },
  {
    question: 'O site funciona perfeitamente no celular?',
    answer:
      'Com certeza. Mais de 85% dos visitantes de sites hoje acessam pelo smartphone. Por isso, todos os nossos projetos são desenvolvidos com tecnologia mobile-first, garantindo carregamento instantâneo, botões fáceis de clicar e leitura perfeita em qualquer tamanho de tela.',
  },
  {
    question: 'Eu já preciso ter domínio e hospedagem contratados?',
    answer:
      'Não se preocupe! Nós te orientamos passo a passo na escolha e registro do domínio (ex: suaempresa.com.br) e configuramos toda a hospedagem segura com certificado SSL gratuito (o cadeado verde de segurança). Cuidamos da parte técnica para você não se preocupar com nada.',
  },
  {
    question: 'Como o site ajuda a aumentar o faturamento da minha empresa?',
    answer:
      'Um site profissional gera credibilidade imediata. Quando um cliente em potencial pesquisa seu produto ou serviço, ele compara você com seus concorrentes. Um site da Nexo Criative posiciona sua marca como líder de mercado, quebra objeções e direciona o visitante com clareza para o botão de WhatsApp.',
  },
  {
    question: 'Quais são as formas de pagamento disponíveis?',
    answer:
      'Trabalhamos com Pix (com condições especiais para início imediato) e cartão de crédito com parcelamento facilitado. Entre em contato pelo WhatsApp para receber uma proposta personalizada para a sua realidade.',
  },
];
