import React, { useState, useEffect } from 'react';
import { BRAND_CONFIG, getWhatsAppUrl } from '../data/agencyData.ts';
import { MessageSquare, Menu, X, ArrowUpRight, Instagram } from 'lucide-react';

export const Navbar: React.FC = () => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Sobre', href: '#sobre' },
    { label: 'Serviços', href: '#servicos' },
    { label: 'Portfólio', href: '#portfolio' },
    { label: 'Depoimentos', href: '#depoimentos' },
    { label: 'Contato', href: '#contato' },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-[#0A0A0A]/90 backdrop-blur-md border-b border-[var(--border-gold)]/40 shadow-lg'
          : 'bg-transparent border-b border-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20 gap-8">
          {/* Zone 1: Brand Wordmark (Single Text Element) */}
          <a
            href="#"
            className="flex items-center gap-3 group whitespace-nowrap shrink-0"
            aria-label="Nexo Criative - Página Inicial"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#1C1C24] to-[#0A0A0A] border border-[var(--border-gold)] flex items-center justify-center text-[#D4AF37] font-bold text-xl shadow-sm group-hover:border-[#D4AF37] transition-colors">
              N
            </div>
            <div className="flex flex-col">
              <span className="font-display font-bold text-xl tracking-tight text-white group-hover:text-[#F3E5AB] transition-colors">
                Nexo <span className="gold-text-gradient">Criative</span>
              </span>
              <span className="text-[10px] tracking-wider uppercase text-[#8F8C84] -mt-1 font-medium">
                Agência de Sites
              </span>
            </div>
          </a>

          {/* Zone 2: 4-5 Clean Nav Links */}
          <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-[#D4D0C7]" aria-label="Navegação Principal">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="hover:text-[#D4AF37] transition-colors whitespace-nowrap shrink-0 relative py-1 after:absolute after:bottom-0 after:left-0 after:w-0 after:h-0.5 after:bg-[#D4AF37] hover:after:w-full after:transition-all"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Zone 3: 1 Primary Action + Instagram */}
          <div className="hidden lg:flex items-center gap-4 shrink-0">
            <a
              href={BRAND_CONFIG.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Instagram da Nexo Criative"
              className="p-2.5 rounded-lg text-[#D4D0C7] hover:text-[#D4AF37] hover:bg-white/5 border border-transparent hover:border-[var(--border-subtle)] transition-all"
              title="Siga @nexocriativeoficial no Instagram"
            >
              <Instagram className="w-4 h-4" />
            </a>

            <a
              href={getWhatsAppUrl('Olá, Nexo Criative! Gostaria de solicitar um orçamento para o site da minha empresa.')}
              target="_blank"
              rel="noopener noreferrer"
              className="gold-cta-btn px-5 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <MessageSquare className="w-4 h-4 text-[#0A0A0A]" />
              <span>Orçamento no WhatsApp</span>
              <ArrowUpRight className="w-3.5 h-3.5 text-[#0A0A0A]" />
            </a>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex md:hidden items-center gap-2">
            <a
              href={getWhatsAppUrl()}
              target="_blank"
              rel="noopener noreferrer"
              className="gold-cta-btn p-2 rounded-lg text-xs"
              aria-label="Falar no WhatsApp"
            >
              <MessageSquare className="w-4 h-4 text-[#0A0A0A]" />
            </a>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-[#D4D0C7] hover:text-white border border-[var(--border-subtle)]"
              aria-label={mobileMenuOpen ? 'Fechar menu' : 'Abrir menu'}
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#0A0A0A]/95 border-b border-[var(--border-gold)]/30 px-6 py-6 space-y-4 backdrop-blur-xl">
          <nav className="flex flex-col space-y-3">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="text-base font-medium text-[#D4D0C7] hover:text-[#D4AF37] py-2 border-b border-white/5"
              >
                {link.label}
              </a>
            ))}
          </nav>
          
          <div className="pt-2 flex flex-col gap-3">
            <a
              href={BRAND_CONFIG.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-sm text-[#A3A3A8] hover:text-[#D4AF37] py-1"
            >
              <Instagram className="w-4 h-4 text-[#D4AF37]" />
              <span>@nexocriativeoficial</span>
            </a>
            <a
              href={getWhatsAppUrl('Olá! Quero um orçamento de site para a minha empresa.')}
              target="_blank"
              rel="noopener noreferrer"
              className="gold-cta-btn w-full py-3 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2"
            >
              <MessageSquare className="w-4 h-4 text-[#0A0A0A]" />
              <span>Solicitar Orçamento no WhatsApp</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
