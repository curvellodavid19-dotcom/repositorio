import React, { useState, useEffect } from 'react';
import { BRAND_CONFIG, getWhatsAppUrl } from '../data/agencyData.ts';
import { MessageSquare, X, Sparkles } from 'lucide-react';

export const FloatingWhatsApp: React.FC = () => {
  const [showTooltip, setShowTooltip] = useState(false);
  const [isDismissed, setIsDismissed] = useState(false);

  useEffect(() => {
    // Show tooltip after 4 seconds of page dwell to catch attention without being intrusive
    const timer = setTimeout(() => {
      if (!isDismissed) {
        setShowTooltip(true);
      }
    }, 4000);
    return () => clearTimeout(timer);
  }, [isDismissed]);

  const handleDismiss = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowTooltip(false);
    setIsDismissed(true);
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end pointer-events-auto">
      {/* Speech Balloon / Tooltip */}
      {showTooltip && (
        <div
          onClick={() => {
            window.open(
              getWhatsAppUrl('Olá, equipe Nexo Criative! Vim pelo botão flutuante e gostaria de tirar uma dúvida sobre sites.'),
              '_blank',
              'noopener,noreferrer'
            );
          }}
          className="mb-3 max-w-[280px] p-4 rounded-2xl bg-[#141419]/95 border border-[var(--border-gold)] text-white shadow-2xl backdrop-blur-md cursor-pointer relative group transition-all duration-300 hover:scale-102"
        >
          <button
            onClick={handleDismiss}
            className="absolute top-2 right-2 p-1 text-[#8F8C84] hover:text-white rounded-full bg-black/40"
            aria-label="Fechar balão do WhatsApp"
          >
            <X className="w-3.5 h-3.5" />
          </button>

          <div className="flex items-center gap-2 mb-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span className="text-[11px] font-bold tracking-wide uppercase text-[#D4AF37]">
              Atendimento Online
            </span>
          </div>

          <p className="text-xs text-[#FAF8F5] leading-snug font-medium">
            Tire suas dúvidas ou receba uma estimativa em menos de 5 minutos!
          </p>
          <div className="text-[10px] text-[#A3A3A8] mt-1.5 flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-[#D4AF37]" />
            <span>Resposta 100% humanizada</span>
          </div>
        </div>
      )}

      {/* Floating Circular Action Button */}
      <a
        href={getWhatsAppUrl('Olá, Nexo Criative! Vim pelo site e gostaria de solicitar um orçamento para o meu negócio.')}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Abrir conversa no WhatsApp oficial da Nexo Criative"
        className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-gradient-to-tr from-[#D4AF37] via-[#F3E5AB] to-[#B8860B] text-[#0A0A0A] flex items-center justify-center shadow-2xl hover:scale-110 active:scale-95 transition-all duration-300 relative group animate-gold-pulse"
      >
        <MessageSquare className="w-7 h-7 sm:w-8 sm:h-8 text-[#0A0A0A] fill-[#0A0A0A]" />
        
        {/* Active status ring */}
        <span className="absolute -top-1 -right-1 flex h-4 w-4">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-4 w-4 bg-emerald-500 border-2 border-[#0A0A0A]"></span>
        </span>
      </a>
    </div>
  );
};
