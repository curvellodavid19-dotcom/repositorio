import React from 'react';
import { BRAND_CONFIG, DIFFERENTIALS, getWhatsAppUrl } from '../data/agencyData.ts';
import { Target, Users2, Clock, Award, CheckCircle2, XCircle, ArrowRight } from 'lucide-react';

export const AboutSection: React.FC = () => {
  return (
    <section id="sobre" className="py-24 bg-[#0A0A0A] relative border-t border-[var(--border-subtle)]">
      {/* Decorative ambient gradient */}
      <div className="absolute top-1/2 left-0 w-[450px] h-[450px] bg-[#D4AF37]/5 blur-[140px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <div className="inline-flex items-center gap-2 text-xs font-bold tracking-widest uppercase text-[#D4AF37] mb-3">
            <span>01 · Quem Somos & Manifesto</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight font-display">
            Criatividade, tecnologia e estratégia para <span className="gold-text-gradient">faturar mais</span>.
          </h2>
        </div>

        {/* Story & Manifesto Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start mb-20">
          
          {/* Main About Text as requested */}
          <div className="lg:col-span-7 space-y-6">
            <div className="p-8 rounded-2xl bg-[#121217] border border-[var(--border-gold)]/40 shadow-xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#D4AF37]/10 rounded-full blur-2xl" />
              
              <p className="text-base sm:text-lg text-[#FAF8F5] font-normal leading-relaxed mb-6">
                "{BRAND_CONFIG.aboutText}"
              </p>

              <div className="pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-4 text-xs text-[#8F8C84]">
                <div>
                  <span className="text-[#FAF8F5] font-semibold block text-sm">Nexo Criative</span>
                  <span>Agência Digital de Sites</span>
                </div>
                <div className="text-right">
                  <span className="text-[#D4AF37] font-semibold block">{BRAND_CONFIG.cityRegion}</span>
                  <span>Foco: {BRAND_CONFIG.targetAudience}</span>
                </div>
              </div>
            </div>

            {/* Quick value cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-5 rounded-xl bg-[#121217]/70 border border-white/5">
                <Target className="w-6 h-6 text-[#D4AF37] mb-2" />
                <h4 className="font-bold text-white text-base">Foco em Faturamento</h4>
                <p className="text-xs text-[#D4D0C7] mt-1 leading-relaxed">
                  Não criamos sites apenas para "ficar bonito". Cada página é desenhada para guiar o visitante até a compra ou contato.
                </p>
              </div>

              <div className="p-5 rounded-xl bg-[#121217]/70 border border-white/5">
                <Users2 className="w-6 h-6 text-[#D4AF37] mb-2" />
                <h4 className="font-bold text-white text-base">Atendimento Humanizado</h4>
                <p className="text-xs text-[#D4D0C7] mt-1 leading-relaxed">
                  Nada de tickets demorados ou robôs. Alinhamos tudo direto pelo WhatsApp com atenção aos detalhes do seu negócio.
                </p>
              </div>
            </div>
          </div>

          {/* Differentials Showcase */}
          <div className="lg:col-span-5 space-y-4">
            <h3 className="text-xl font-bold text-white font-display mb-4 flex items-center gap-2">
              <Award className="w-5 h-5 text-[#D4AF37]" />
              <span>Por que a Nexo Criative é diferente?</span>
            </h3>

            {DIFFERENTIALS.map((diff) => (
              <div
                key={diff.id}
                className="p-5 rounded-xl bg-[#141419] border border-white/5 hover:border-[var(--border-gold)]/60 transition-all duration-300"
              >
                <div className="flex items-center justify-between gap-2 mb-2">
                  <h4 className="font-bold text-white text-sm sm:text-base">{diff.title}</h4>
                  <span className="text-[11px] font-semibold px-2.5 py-0.5 rounded-full bg-[#D4AF37]/15 text-[#F3E5AB] border border-[#D4AF37]/30">
                    {diff.badge}
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-[#A3A3A8] leading-relaxed">
                  {diff.description}
                </p>
              </div>
            ))}
          </div>

        </div>

        {/* Comparison: Agência Comum vs Nexo Criative */}
        <div className="p-8 sm:p-10 rounded-2xl bg-gradient-to-br from-[#121217] to-[#0A0A0A] border border-[var(--border-gold)]/30">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <span className="text-xs uppercase tracking-widest text-[#D4AF37] font-bold">Transparência Total</span>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-white mt-1 font-display">
              Agências Tradicionais vs. Nexo Criative
            </h3>
            <p className="text-sm text-[#8F8C84] mt-2">
              Entenda por que empresas inteligentes escolhem a nossa metodologia ágil.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Outras agências */}
            <div className="p-6 rounded-xl bg-[#0F0F13] border border-white/5 space-y-4 opacity-80">
              <div className="text-sm font-bold text-[#8F8C84] uppercase tracking-wider flex items-center gap-2">
                <XCircle className="w-4 h-4 text-red-400" />
                <span>O mercado tradicional</span>
              </div>
              <ul className="space-y-3 text-xs sm:text-sm text-[#8F8C84]">
                <li className="flex items-start gap-2.5">
                  <XCircle className="w-4 h-4 text-red-400/80 shrink-0 mt-0.5" />
                  <span>30 a 60 dias para entregar um site simples</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <XCircle className="w-4 h-4 text-red-400/80 shrink-0 mt-0.5" />
                  <span>Templates genéricos baixados da internet que parecem cópia</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <XCircle className="w-4 h-4 text-red-400/80 shrink-0 mt-0.5" />
                  <span>Atendimento burocrático via e-mails e tickets demorados</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <XCircle className="w-4 h-4 text-red-400/80 shrink-0 mt-0.5" />
                  <span>Sites pesados que demoram para carregar e perdem clientes</span>
                </li>
              </ul>
            </div>

            {/* Nexo Criative */}
            <div className="p-6 rounded-xl bg-[#171720] border border-[var(--border-gold)] space-y-4 shadow-lg relative overflow-hidden">
              <div className="text-sm font-bold text-[#F3E5AB] uppercase tracking-wider flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#D4AF37]" />
                <span className="gold-text-gradient font-extrabold">Com a Nexo Criative</span>
              </div>
              <ul className="space-y-3 text-xs sm:text-sm text-[#FAF8F5]">
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                  <span className="font-semibold text-white">Opção de entrega no mesmo dia (24h) com foco em velocidade</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                  <span>Design autoral e exclusivo com alto padrão de acabamento</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                  <span>Atendimento 100% humanizado no WhatsApp com o criador</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                  <span>Carregamento em menos de 1 segundo (Google PageSpeed 95+)</span>
                </li>
              </ul>

              <div className="pt-2">
                <a
                  href={getWhatsAppUrl('Olá, equipe Nexo Criative! Quero entender como funciona o processo de criação de vocês.')}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs font-bold text-[#D4AF37] hover:text-[#F3E5AB] inline-flex items-center gap-1.5 transition-colors"
                >
                  <span>Conversar com nosso especialista agora</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
