import React, { useState } from 'react';
import { SERVICES, getWhatsAppUrl } from '../data/agencyData.ts';
import { Check, Clock, MessageSquare, ArrowRight, Zap, Sparkles } from 'lucide-react';

export const ServicesSection: React.FC = () => {
  const [selectedServiceId, setSelectedServiceId] = useState<string>(SERVICES[0].id);

  return (
    <section id="servicos" className="py-24 bg-[#0A0A0A] relative border-t border-[var(--border-subtle)]">
      {/* Ambient background glow */}
      <div className="absolute top-1/3 right-0 w-[500px] h-[500px] bg-[#D4AF37]/5 blur-[150px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <div className="inline-flex items-center gap-2 text-xs font-bold tracking-widest uppercase text-[#D4AF37] mb-3">
            <span>02 · O que fazemos</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight font-display">
            Criação de Sites Profissionais e <span className="gold-text-gradient">Personalizados</span>.
          </h2>
          <p className="text-base sm:text-lg text-[#D4D0C7] mt-4 leading-relaxed">
            Desenvolvemos a solução sob medida para a sua necessidade: desde páginas de alta conversão 
            com entrega no mesmo dia até portais corporativos completos de alto padrão.
          </p>
        </div>

        {/* Services Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-stretch">
          {SERVICES.map((service, index) => {
            const isExpress = service.id === 'site-express-mesmo-dia';
            const isPopular = service.isPopular;

            return (
              <div
                key={service.id}
                onClick={() => setSelectedServiceId(service.id)}
                className={`p-8 rounded-2xl flex flex-col justify-between transition-all duration-300 relative overflow-hidden cursor-pointer ${
                  selectedServiceId === service.id
                    ? 'bg-[#15151D] border-2 border-[var(--border-gold)] shadow-xl'
                    : 'bg-[#121217] border border-white/10 hover:border-[var(--border-gold)]/60'
                }`}
              >
                {/* Express or Popular badge */}
                {isExpress && (
                  <div className="absolute top-6 right-6 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#D4AF37]/20 border border-[#D4AF37] text-[11px] font-bold text-[#F3E5AB]">
                    <Zap className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>Destaque: Mesmo Dia</span>
                  </div>
                )}
                {isPopular && !isExpress && (
                  <div className="absolute top-6 right-6 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 border border-white/20 text-[11px] font-semibold text-white">
                    <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>Mais Solicitado</span>
                  </div>
                )}

                <div>
                  <div className="text-xs font-mono font-bold text-[#8F8C84] mb-2">
                    0{index + 1}
                  </div>
                  <h3 className="text-2xl font-bold text-white font-display">
                    {service.title}
                  </h3>
                  <p className="text-sm font-medium text-[#D4AF37] mt-1 mb-4">
                    {service.subtitle}
                  </p>
                  <p className="text-sm text-[#D4D0C7] leading-relaxed mb-6">
                    {service.description}
                  </p>

                  {/* Delivery time pill */}
                  <div className="flex items-center gap-2 text-xs font-semibold text-[#F3E5AB] bg-[#0A0A0A] px-3.5 py-2 rounded-lg border border-white/5 w-fit mb-6">
                    <Clock className="w-4 h-4 text-[#D4AF37]" />
                    <span>Prazo: {service.deliveryTime}</span>
                  </div>

                  {/* Deliverables list */}
                  <div className="space-y-2.5 mb-8">
                    <span className="text-xs uppercase tracking-wider font-bold text-[#8F8C84] block">
                      O que está incluso:
                    </span>
                    {service.deliverables.map((item, i) => (
                      <div key={i} className="flex items-start gap-2.5 text-xs sm:text-sm text-[#FAF8F5]">
                        <Check className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                        <span>{item}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Footer area of card */}
                <div className="pt-6 border-t border-white/10 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
                  <div className="text-xs text-[#8F8C84]">
                    <span className="font-semibold text-[#D4D0C7] block">Indicado para:</span>
                    <span>{service.idealFor}</span>
                  </div>

                  <a
                    href={getWhatsAppUrl(service.whatsappPreset)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="gold-cta-btn px-5 py-3 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 shrink-0 group"
                  >
                    <MessageSquare className="w-4 h-4 text-[#0A0A0A]" />
                    <span>Pedir Orçamento</span>
                    <ArrowRight className="w-3.5 h-3.5 text-[#0A0A0A] group-hover:translate-x-1 transition-transform" />
                  </a>
                </div>
              </div>
            );
          })}
        </div>

        {/* Custom Project Banner */}
        <div className="mt-12 p-8 rounded-2xl bg-gradient-to-r from-[#171720] via-[#1F1F2A] to-[#121217] border border-[var(--border-gold)]/40 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 text-center md:text-left">
            <h4 className="text-xl font-bold text-white font-display">
              Precisa de um projeto especial ou não sabe qual modelo escolher?
            </h4>
            <p className="text-sm text-[#D4D0C7] max-w-2xl">
              Nosso atendimento é 100% humanizado. Conte seu objetivo pelo WhatsApp e nossa equipe indicará a melhor estratégia sem compromisso.
            </p>
          </div>
          <a
            href={getWhatsAppUrl('Olá, Nexo Criative! Gostaria de uma consultoria rápida para saber qual tipo de site é ideal para meu negócio.')}
            target="_blank"
            rel="noopener noreferrer"
            className="gold-cta-btn px-6 py-3.5 rounded-xl text-xs font-bold uppercase tracking-wider whitespace-nowrap shrink-0 flex items-center gap-2"
          >
            <MessageSquare className="w-4 h-4 text-[#0A0A0A]" />
            <span>Consultoria Gratuita</span>
          </a>
        </div>

      </div>
    </section>
  );
};
