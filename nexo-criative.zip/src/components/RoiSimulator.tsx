import React, { useState } from 'react';
import { getWhatsAppUrl } from '../data/agencyData.ts';
import { Calculator, TrendingUp, AlertTriangle, MessageSquare, ArrowRight } from 'lucide-react';

export const RoiSimulator: React.FC = () => {
  const [ticketMedio, setTicketMedio] = useState<number>(1500);
  const [visitasMes, setVisitasMes] = useState<number>(30);

  // Sem site, estima-se que 60% das buscas vão para o concorrente com site
  const oportunidadesPerdidas = Math.round(visitasMes * 0.4);
  const faturamentoDeixadoNaMesa = oportunidadesPerdidas * ticketMedio;

  return (
    <section className="py-20 bg-gradient-to-b from-[#0A0A0A] via-[#121217] to-[#0A0A0A] relative border-t border-[var(--border-subtle)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="p-8 sm:p-12 rounded-3xl bg-[#14141A] border border-[var(--border-gold)]/60 shadow-2xl relative overflow-hidden">
          {/* Subtle gold decorative glow */}
          <div className="absolute top-0 right-0 w-80 h-80 bg-[#D4AF37]/10 rounded-full blur-3xl pointer-events-none" />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            
            {/* Left Column: Context & Controls */}
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 text-xs font-bold tracking-widest uppercase text-[#D4AF37]">
                <Calculator className="w-4 h-4 text-[#D4AF37]" />
                <span>Simulador de Oportunidades</span>
              </div>

              <h3 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight font-display">
                Quanto faturamento sua empresa está <span className="gold-text-gradient">deixando na mesa</span> sem um site?
              </h3>

              <p className="text-sm text-[#D4D0C7] leading-relaxed">
                Mais de 70% dos clientes pesquisam no Google ou no Instagram antes de fechar qualquer serviço. 
                Quando não encontram seu site oficial, eles contratam o seu concorrente.
              </p>

              {/* Sliders */}
              <div className="space-y-6 pt-2">
                <div>
                  <div className="flex justify-between items-center text-xs font-semibold text-[#FAF8F5] mb-2">
                    <span>Ticket médio do seu serviço / produto:</span>
                    <span className="text-[#D4AF37] text-sm font-bold font-mono">
                      R$ {ticketMedio.toLocaleString('pt-BR')}
                    </span>
                  </div>
                  <input
                    type="range"
                    min="300"
                    max="10000"
                    step="100"
                    value={ticketMedio}
                    onChange={(e) => setTicketMedio(Number(e.target.value))}
                    className="w-full h-2 bg-[#0A0A0A] rounded-lg appearance-none cursor-pointer accent-[#D4AF37]"
                  />
                  <div className="flex justify-between text-[10px] text-[#8F8C84] mt-1">
                    <span>R$ 300</span>
                    <span>R$ 5.000</span>
                    <span>R$ 10.000+</span>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between items-center text-xs font-semibold text-[#FAF8F5] mb-2">
                    <span>Contatos ou orçamentos que você recebe por mês:</span>
                    <span className="text-[#D4AF37] text-sm font-bold font-mono">
                      {visitasMes} contatos/mês
                    </span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="200"
                    step="5"
                    value={visitasMes}
                    onChange={(e) => setVisitasMes(Number(e.target.value))}
                    className="w-full h-2 bg-[#0A0A0A] rounded-lg appearance-none cursor-pointer accent-[#D4AF37]"
                  />
                  <div className="flex justify-between text-[10px] text-[#8F8C84] mt-1">
                    <span>10/mês</span>
                    <span>100/mês</span>
                    <span>200+/mês</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column: Calculated Impact Result Card */}
            <div className="lg:col-span-5">
              <div className="p-8 rounded-2xl bg-[#0A0A0A] border border-[var(--border-gold)] shadow-xl space-y-6 text-center lg:text-left">
                <div className="flex items-center justify-center lg:justify-start gap-2 text-xs font-bold text-amber-400">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  <span>Estimativa de Oportunidades Perdidas</span>
                </div>

                <div>
                  <span className="text-xs text-[#8F8C84] uppercase tracking-wider block">
                    Faturamento que vai para o concorrente todo mês:
                  </span>
                  <div className="text-3xl sm:text-4xl font-extrabold text-[#D4AF37] font-display mt-1">
                    R$ {faturamentoDeixadoNaMesa.toLocaleString('pt-BR')}
                    <span className="text-xs text-[#8F8C84] font-normal"> / mês</span>
                  </div>
                  <div className="text-xs text-[#A3A3A8] mt-1">
                    Equivalente a cerca de <strong className="text-white">R$ {(faturamentoDeixadoNaMesa * 12).toLocaleString('pt-BR')}</strong> por ano.
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-[#141419] border border-white/5 text-xs text-[#D4D0C7] text-left leading-relaxed">
                  💡 Um site profissional da Nexo Criative se paga rapidamente logo nos primeiros clientes conquistados. 
                  Com a nossa opção de entrega no mesmo dia, você já começa a reverter esse cenário imediatamente.
                </div>

                <a
                  href={getWhatsAppUrl(`Olá Nexo Criative! Fiz a simulação no site e vi que estou deixando cerca de R$ ${faturamentoDeixadoNaMesa.toLocaleString('pt-BR')} na mesa. Quero solicitar um orçamento para criar meu site.`)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="gold-cta-btn w-full py-4 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 group cursor-pointer"
                >
                  <MessageSquare className="w-4 h-4 text-[#0A0A0A]" />
                  <span>Quero recuperar essas vendas</span>
                  <ArrowRight className="w-3.5 h-3.5 text-[#0A0A0A] group-hover:translate-x-1 transition-transform" />
                </a>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
