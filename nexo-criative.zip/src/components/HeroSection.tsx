import React from 'react';
import { BRAND_CONFIG, getWhatsAppUrl } from '../data/agencyData.ts';
import { MessageSquare, ArrowRight, ShieldCheck, Zap, Sparkles, CheckCircle2 } from 'lucide-react';

export const HeroSection: React.FC = () => {
  return (
    <section className="relative pt-24 pb-14 md:pt-28 md:pb-16 overflow-hidden bg-gradient-to-b from-[#0A0A0A] via-[#0D0D12] to-[#0A0A0A]">
      {/* Subtle gold ambient glow in the background */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-[#D4AF37]/10 blur-[130px] rounded-full pointer-events-none -z-10" />
      <div className="absolute top-10 right-10 w-[300px] h-[300px] bg-[#D4AF37]/5 blur-[100px] rounded-full pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Provocative Headline & CTAs */}
          <div className="lg:col-span-7 flex flex-col justify-center space-y-6">
            
            {/* Tagline kicker with luxury accent */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#181820] border border-[var(--border-gold)]/50 text-xs font-semibold text-[#F3E5AB] w-fit shadow-sm">
              <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span className="tracking-wide">Entrega express no mesmo dia disponível</span>
              <span className="text-[#8F8C84]">·</span>
              <span className="text-[#D4AF37] font-bold">Brasil</span>
            </div>

            {/* Main Tagline & Headline */}
            <div className="space-y-2">
              <p className="text-xs sm:text-sm font-bold tracking-wider uppercase text-[#D4AF37] font-display">
                {BRAND_CONFIG.tagline}
              </p>
              
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight leading-[1.2] font-display">
                Criamos sites de <span className="gold-text-gradient">alto padrão</span> que aumentam seu <span className="underline decoration-[#D4AF37]/50 underline-offset-8">faturamento</span>.
              </h1>
            </div>

            {/* Value Proposition Description */}
            <p className="text-sm sm:text-base text-[#D4D0C7] max-w-xl leading-relaxed">
              Não entregamos apenas código: construímos o ativo digital mais valioso do seu negócio. 
              Design exclusivo, velocidade máxima no celular e estrutura focada em levar o cliente 
              direto para o seu WhatsApp.
            </p>

            {/* Actions: Primary CTA + Secondary Link */}
            <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
              <a
                href={getWhatsAppUrl('Olá, Nexo Criative! Vi a frase "Seu concorrente já tem site. E você?" e decidi solicitar um orçamento para meu negócio.')}
                target="_blank"
                rel="noopener noreferrer"
                className="gold-cta-btn px-8 py-3.5 rounded-xl text-xs sm:text-sm font-extrabold tracking-wide uppercase flex items-center justify-center gap-3 shadow-lg group cursor-pointer"
              >
                <MessageSquare className="w-4 h-4 text-[#0A0A0A]" />
                <span>Solicitar Orçamento no WhatsApp</span>
                <ArrowRight className="w-4 h-4 text-[#0A0A0A] group-hover:translate-x-1 transition-transform" />
              </a>

              <a
                href="#portfolio"
                className="gold-outline-btn px-6 py-3.5 rounded-xl text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 hover:text-white"
              >
                <span>Ver Portfólio de Sites</span>
              </a>
            </div>

            {/* Quick trust bullets */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2 text-xs sm:text-sm text-[#FAF8F5]">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37] shrink-0" />
                <span>Entrega no mesmo dia (24h)</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37] shrink-0" />
                <span>Atendimento 100% humanizado</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37] shrink-0" />
                <span>Otimizado para celular e Google</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37] shrink-0" />
                <span>Foco total em conversão</span>
              </div>
            </div>

            {/* Micro reassurance label */}
            <div className="flex items-center gap-3 text-xs text-[#8F8C84] pt-1">
              <ShieldCheck className="w-4 h-4 text-[#D4AF37]" />
              <span>Sem compromisso · Resposta ágil pelo WhatsApp da equipe</span>
            </div>
          </div>

          {/* Right Column: Hero Visual Showcase */}
          <div className="lg:col-span-5 relative">
            <div className="relative group">
              {/* Outer decorative gold frame border */}
              <div className="absolute -inset-1 bg-gradient-to-r from-[#D4AF37]/30 via-[#F3E5AB]/20 to-[#B8860B]/30 rounded-2xl blur-md opacity-75 group-hover:opacity-100 transition duration-700" />
              
              <div className="relative rounded-2xl overflow-hidden border border-[var(--border-gold)] bg-[#121217] shadow-2xl">
                {/* Browser top bar preview */}
                <div className="bg-[#1A1A22] px-4 py-3 border-b border-white/5 flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <div className="w-2.5 h-2.5 rounded-full bg-red-500/80" />
                    <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/80" />
                    <div className="w-2.5 h-2.5 rounded-full bg-green-500/80" />
                  </div>
                  <div className="text-[11px] font-mono text-[#8F8C84] bg-[#0A0A0A] px-3 py-1 rounded-md border border-white/5 truncate max-w-[200px]">
                    nexocriative.com.br/showcase
                  </div>
                  <div className="text-[10px] text-[#D4AF37] font-semibold">
                    ALTA CONVERSÃO
                  </div>
                </div>

                {/* Showcase image */}
                <img
                  src="/src/assets/images/hero_agency_showcase_1794197678116.jpg"
                  alt="Showcase de sites profissionais da Nexo Criative"
                  className="w-full h-auto object-cover transform group-hover:scale-102 transition duration-500"
                  loading="eager"
                  referrerPolicy="no-referrer"
                />

                {/* Floating overlay tag */}
                <div className="absolute bottom-4 left-4 right-4 bg-[#0A0A0A]/85 backdrop-blur-md p-4 rounded-xl border border-[var(--border-gold)]/60 flex items-center justify-between shadow-xl">
                  <div>
                    <div className="text-xs text-[#8F8C84] uppercase tracking-wider font-semibold">Nexo Criative Standard</div>
                    <div className="text-sm font-bold text-white">Design Autoral & Foco em Faturamento</div>
                  </div>
                  <div className="text-right">
                    <span className="text-xs text-[#D4AF37] font-bold block">100% Humanizado</span>
                    <span className="text-[11px] text-[#D4D0C7]">Brasil todo</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* 4-Item Proof KPI Strip */}
        <div className="mt-16 pt-10 border-t border-[var(--border-subtle)] grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          <div className="p-4 rounded-xl bg-[#121217]/50 border border-white/5">
            <div className="text-2xl sm:text-3xl font-extrabold text-white font-display tabular-nums">
              +120
            </div>
            <div className="text-xs text-[#8F8C84] mt-1 uppercase tracking-wider font-medium">
              Sites Entregues
            </div>
          </div>

          <div className="p-4 rounded-xl bg-[#121217]/50 border border-white/5">
            <div className="text-2xl sm:text-3xl font-extrabold text-[#D4AF37] font-display tabular-nums flex items-center justify-center gap-1">
              <Zap className="w-5 h-5 text-[#D4AF37]" />
              <span>24h</span>
            </div>
            <div className="text-xs text-[#8F8C84] mt-1 uppercase tracking-wider font-medium">
              Entrega no Mesmo Dia
            </div>
          </div>

          <div className="p-4 rounded-xl bg-[#121217]/50 border border-white/5">
            <div className="text-2xl sm:text-3xl font-extrabold text-white font-display tabular-nums">
              98/100
            </div>
            <div className="text-xs text-[#8F8C84] mt-1 uppercase tracking-wider font-medium">
              Velocidade Google PageSpeed
            </div>
          </div>

          <div className="p-4 rounded-xl bg-[#121217]/50 border border-white/5">
            <div className="text-2xl sm:text-3xl font-extrabold text-[#F3E5AB] font-display">
              100%
            </div>
            <div className="text-xs text-[#8F8C84] mt-1 uppercase tracking-wider font-medium">
              Atendimento Humanizado
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
