import React, { useState } from 'react';
import { TESTIMONIALS, FAQS, getWhatsAppUrl } from '../data/agencyData.ts';
import { Star, Quote, ChevronDown, ChevronUp, MessageSquare, ShieldCheck } from 'lucide-react';

export const TestimonialsSection: React.FC = () => {
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const toggleFaq = (index: number) => {
    setOpenFaqIndex(openFaqIndex === index ? null : index);
  };

  return (
    <section id="depoimentos" className="py-24 bg-[#0A0A0A] relative border-t border-[var(--border-subtle)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <div className="inline-flex items-center gap-2 text-xs font-bold tracking-widest uppercase text-[#D4AF37] mb-3">
            <span>04 · Prova Social & Resultados Reais</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight font-display">
            O que dizem os empresários que <span className="gold-text-gradient">faturam mais</span> conosco.
          </h2>
          <p className="text-base text-[#D4D0C7] mt-3 leading-relaxed">
            Relatos de quem confiou na Nexo Criative para construir sua presença digital e colheu resultados no faturamento.
          </p>
        </div>

        {/* Testimonials Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
          {TESTIMONIALS.map((testimonial) => (
            <div
              key={testimonial.id}
              className="p-8 rounded-2xl bg-[#121217] border border-[var(--border-gold)]/40 hover:border-[var(--border-gold)] transition-all duration-300 flex flex-col justify-between shadow-xl relative"
            >
              <div>
                {/* 5 Stars Rating */}
                <div className="flex items-center gap-1 mb-4 text-[#D4AF37]">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-[#D4AF37]" />
                  ))}
                  <span className="text-xs font-bold text-[#F3E5AB] ml-2">5.0</span>
                </div>

                {/* Impact metric badge */}
                <div className="inline-block px-3 py-1 rounded-md bg-[#D4AF37]/15 text-[#F3E5AB] text-xs font-bold border border-[#D4AF37]/30 mb-4">
                  {testimonial.metric}
                </div>

                {/* Content */}
                <p className="text-sm text-[#D4D0C7] leading-relaxed italic relative">
                  "{testimonial.content}"
                </p>
              </div>

              {/* Author footer */}
              <div className="pt-6 mt-6 border-t border-white/10 flex items-center gap-3">
                <img
                  src={testimonial.avatar}
                  alt={testimonial.name}
                  className="w-11 h-11 rounded-full object-cover border-2 border-[var(--border-gold)]"
                  loading="lazy"
                  referrerPolicy="no-referrer"
                />
                <div>
                  <div className="text-sm font-bold text-white font-display">
                    {testimonial.name}
                  </div>
                  <div className="text-xs text-[#8F8C84]">
                    {testimonial.role} · <span className="text-[#D4AF37]">{testimonial.company}</span>
                  </div>
                  <div className="text-[11px] text-[#A3A3A8] mt-0.5">
                    {testimonial.city}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Interactive FAQ Section to clarify all doubts */}
        <div className="mt-20 pt-16 border-t border-white/10">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <span className="text-xs font-bold uppercase tracking-widest text-[#D4AF37]">
              Tire Suas Dúvidas
            </span>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-white mt-2 font-display">
              Perguntas Frequentes sobre a Criação de Sites
            </h3>
            <p className="text-sm text-[#8F8C84] mt-2">
              Tudo o que você precisa saber sobre prazos, entrega express e atendimento.
            </p>
          </div>

          <div className="max-w-3xl mx-auto space-y-3">
            {FAQS.map((faq, index) => {
              const isOpen = openFaqIndex === index;
              return (
                <div
                  key={index}
                  className="rounded-xl bg-[#121217] border border-white/5 overflow-hidden transition-all duration-200"
                >
                  <button
                    onClick={() => toggleFaq(index)}
                    className="w-full p-5 text-left flex items-center justify-between gap-4 cursor-pointer hover:bg-white/5 transition-colors"
                    aria-expanded={isOpen}
                  >
                    <span className="text-sm sm:text-base font-semibold text-white">
                      {faq.question}
                    </span>
                    {isOpen ? (
                      <ChevronUp className="w-5 h-5 text-[#D4AF37] shrink-0" />
                    ) : (
                      <ChevronDown className="w-5 h-5 text-[#8F8C84] shrink-0" />
                    )}
                  </button>
                  {isOpen && (
                    <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-[#D4D0C7] leading-relaxed border-t border-white/5">
                      {faq.answer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Quick FAQ footer reassurance */}
          <div className="mt-8 text-center">
            <a
              href={getWhatsAppUrl('Olá Nexo Criative! Tenho uma dúvida sobre os serviços de criação de sites.')}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 text-xs font-bold text-[#D4AF37] hover:text-[#F3E5AB] transition-colors"
            >
              <MessageSquare className="w-4 h-4" />
              <span>Ainda tem dúvidas? Fale agora no WhatsApp com nosso atendimento humanizado</span>
            </a>
          </div>
        </div>

      </div>
    </section>
  );
};
