import React from 'react';
import { BRAND_CONFIG, getWhatsAppUrl } from '../data/agencyData.ts';
import { Instagram, Phone, ArrowUp, ShieldCheck, Download } from 'lucide-react';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#050505] text-[#8F8C84] border-t border-[var(--border-subtle)] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 items-start">
          
          {/* Brand Col */}
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#1C1C24] to-[#0A0A0A] border border-[var(--border-gold)] flex items-center justify-center text-[#D4AF37] font-bold text-xl">
                N
              </div>
              <span className="font-display font-bold text-xl tracking-tight text-white">
                Nexo <span className="gold-text-gradient">Criative</span>
              </span>
            </div>

            <p className="text-sm text-[#A3A3A8] max-w-sm leading-relaxed">
              Agência digital especializada na criação de sites profissionais, modernos e de alta conversão. "{BRAND_CONFIG.tagline}"
            </p>

            <div className="flex items-center gap-3 pt-2">
              <a
                href={BRAND_CONFIG.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-xl bg-[#121217] border border-white/10 flex items-center justify-center text-[#D4D0C7] hover:text-[#D4AF37] hover:border-[#D4AF37] transition-all"
                aria-label="Instagram da Nexo Criative"
              >
                <Instagram className="w-4 h-4" />
              </a>

              <a
                href={getWhatsAppUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-xl bg-[#121217] border border-white/10 flex items-center justify-center text-[#D4D0C7] hover:text-[#D4AF37] hover:border-[#D4AF37] transition-all"
                aria-label="WhatsApp da Nexo Criative"
              >
                <Phone className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Nav Col */}
          <div className="md:col-span-3 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-widest text-[#D4AF37]">
              Navegação
            </h4>
            <ul className="space-y-2 text-sm text-[#D4D0C7]">
              <li>
                <a href="#sobre" className="hover:text-[#D4AF37] transition-colors">
                  Sobre a Nexo
                </a>
              </li>
              <li>
                <a href="#servicos" className="hover:text-[#D4AF37] transition-colors">
                  Serviços de Criação de Sites
                </a>
              </li>
              <li>
                <a href="#portfolio" className="hover:text-[#D4AF37] transition-colors">
                  Portfólio & Casos Reais
                </a>
              </li>
              <li>
                <a href="#depoimentos" className="hover:text-[#D4AF37] transition-colors">
                  Depoimentos de Clientes
                </a>
              </li>
              <li>
                <a href="#contato" className="hover:text-[#D4AF37] transition-colors">
                  Solicitar Orçamento
                </a>
              </li>
            </ul>
          </div>

          {/* Contact & Legal Col */}
          <div className="md:col-span-4 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-widest text-[#D4AF37]">
              Atendimento Oficial
            </h4>
            <p className="text-sm text-[#D4D0C7]">
              WhatsApp: <strong className="text-white">{BRAND_CONFIG.whatsappDisplay}</strong>
            </p>
            <p className="text-sm text-[#D4D0C7]">
              Instagram: <strong className="text-white">{BRAND_CONFIG.instagramHandle}</strong>
            </p>
            <p className="text-xs text-[#8F8C84] pt-2">
              Atendimento humanizado em todo o território nacional · Brasil
            </p>
            <div className="inline-flex items-center gap-1.5 text-xs text-[#D4AF37] pt-1">
              <ShieldCheck className="w-4 h-4" />
              <span>Garantia de Entrega & Segurança SSL</span>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#8F8C84]">
          <div>
            © {new Date().getFullYear()} Nexo Criative. Todos os direitos reservados.
          </div>

          <div className="flex flex-wrap items-center gap-4 sm:gap-6">
            <a
              href="/nexo-criative.zip"
              download="nexo-criative.zip"
              className="p-2 px-3 rounded-lg bg-[#141419] hover:bg-[#1A1A22] text-[#D4AF37] hover:text-[#F3E5AB] border border-[#D4AF37]/30 hover:border-[#D4AF37] transition-all flex items-center gap-1.5 cursor-pointer font-medium"
              title="Baixar arquivo ZIP completo do código para Lovable"
            >
              <Download className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>Baixar ZIP (Lovable)</span>
            </a>

            <button
              onClick={scrollToTop}
              className="p-2 rounded-lg bg-[#121217] hover:bg-[#1A1A22] text-[#D4D0C7] hover:text-[#D4AF37] border border-white/10 transition-colors flex items-center gap-1 cursor-pointer"
              aria-label="Voltar ao topo da página"
            >
              <span>Topo</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
