import React, { useState } from 'react';
import { BRAND_CONFIG, getWhatsAppUrl } from '../data/agencyData.ts';
import { MessageSquare, Send, CheckCircle2, ShieldCheck, Zap, Instagram, Phone, Clock } from 'lucide-react';

export const ContactSection: React.FC = () => {
  const [formState, setFormState] = useState({
    name: '',
    whatsapp: '',
    businessType: '',
    serviceType: 'Landing Page de Alta Conversão',
    urgency: 'Urgência máxima · Quero entrega no mesmo dia (24h)',
    message: '',
  });

  const [submitted, setSubmitted] = useState(false);
  const [generatedUrl, setGeneratedUrl] = useState('');

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormState((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Compose formatted WhatsApp message
    const formattedText = `*SOLICITAÇÃO DE ORÇAMENTO - NEXO CRIATIVE*
---------------------------------------
👤 *Nome/Empresa:* ${formState.name || 'Não informado'}
📱 *WhatsApp:* ${formState.whatsapp || 'Não informado'}
🏢 *Ramo do Negócio:* ${formState.businessType || 'Geral'}
🎯 *Tipo de Site:* ${formState.serviceType}
⚡ *Prazo Desejado:* ${formState.urgency}
💬 *Detalhes:* ${formState.message || 'Gostaria de conversar sobre a proposta comercial.'}
---------------------------------------
Vim pelo site da Nexo Criative e aguardo atendimento humanizado!`;

    const url = getWhatsAppUrl(formattedText);
    setGeneratedUrl(url);
    setSubmitted(true);

    // Open WhatsApp in new tab
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="contato" className="py-24 bg-[#0A0A0A] relative border-t border-[var(--border-subtle)]">
      {/* Background glow */}
      <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] bg-[#D4AF37]/5 blur-[150px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <div className="inline-flex items-center gap-2 text-xs font-bold tracking-widest uppercase text-[#D4AF37] mb-3">
            <span>05 · Inicie Seu Projeto</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight font-display">
            Seu concorrente já tem site. <span className="gold-text-gradient">E você?</span>
          </h2>
          <p className="text-base text-[#D4D0C7] mt-3 leading-relaxed">
            Preencha os dados abaixo e fale diretamente com o estrategista responsável pelo seu projeto. 
            Sem intermediários ou respostas automáticas.
          </p>
        </div>

        {/* Contact Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Left Column: Direct Contact Info & Reassurances */}
          <div className="lg:col-span-5 space-y-6">
            <div className="p-8 rounded-2xl bg-[#121217] border border-[var(--border-gold)]/40 shadow-xl space-y-6">
              <h3 className="text-xl font-bold text-white font-display">
                Canais de Atendimento Direto
              </h3>
              <p className="text-sm text-[#D4D0C7] leading-relaxed">
                Preferimos a agilidade do WhatsApp. Você recebe um atendimento humano, consultivo e focado 
                na realidade financeira e de vendas da sua empresa.
              </p>

              <div className="space-y-4 pt-2">
                {/* WhatsApp */}
                <a
                  href={getWhatsAppUrl()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-4 p-4 rounded-xl bg-[#171720] border border-white/5 hover:border-[var(--border-gold)] transition-colors group"
                >
                  <div className="w-12 h-12 rounded-lg bg-[#D4AF37]/15 border border-[#D4AF37]/40 flex items-center justify-center text-[#D4AF37] shrink-0 group-hover:scale-105 transition-transform">
                    <Phone className="w-5 h-5 text-[#D4AF37]" />
                  </div>
                  <div>
                    <span className="text-xs text-[#8F8C84] uppercase tracking-wider block">WhatsApp Oficial</span>
                    <span className="text-base font-bold text-white group-hover:text-[#F3E5AB]">
                      {BRAND_CONFIG.whatsappDisplay}
                    </span>
                    <span className="text-[11px] text-[#D4AF37] block mt-0.5">Resposta média em minutos</span>
                  </div>
                </a>

                {/* Instagram */}
                <a
                  href={BRAND_CONFIG.instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-4 p-4 rounded-xl bg-[#171720] border border-white/5 hover:border-[var(--border-gold)] transition-colors group"
                >
                  <div className="w-12 h-12 rounded-lg bg-[#D4AF37]/15 border border-[#D4AF37]/40 flex items-center justify-center text-[#D4AF37] shrink-0 group-hover:scale-105 transition-transform">
                    <Instagram className="w-5 h-5 text-[#D4AF37]" />
                  </div>
                  <div>
                    <span className="text-xs text-[#8F8C84] uppercase tracking-wider block">Instagram Oficial</span>
                    <span className="text-base font-bold text-white group-hover:text-[#F3E5AB]">
                      {BRAND_CONFIG.instagramHandle}
                    </span>
                    <span className="text-[11px] text-[#A3A3A8] block mt-0.5">Acompanhe novos projetos e bastidores</span>
                  </div>
                </a>
              </div>

              {/* Guarantees */}
              <div className="pt-4 border-t border-white/10 space-y-3 text-xs text-[#FAF8F5]">
                <div className="flex items-center gap-2.5">
                  <Zap className="w-4 h-4 text-[#D4AF37] shrink-0" />
                  <span>Opção de entrega no mesmo dia para páginas prioritárias</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <ShieldCheck className="w-4 h-4 text-[#D4AF37] shrink-0" />
                  <span>Segurança SSL e código moderno sem mensalidades ocultas</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Clock className="w-4 h-4 text-[#D4AF37] shrink-0" />
                  <span>Atendimento rápido de segunda a sábado</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Interactive Lead Capture Form */}
          <div className="lg:col-span-7">
            <div className="p-8 sm:p-10 rounded-2xl bg-[#121217] border border-[var(--border-gold)] shadow-2xl relative">
              
              {submitted ? (
                <div className="text-center py-10 space-y-4">
                  <div className="w-16 h-16 rounded-full bg-[#D4AF37]/20 border-2 border-[#D4AF37] flex items-center justify-center mx-auto text-[#D4AF37]">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <h3 className="text-2xl font-bold text-white font-display">
                    Solicitação Encaminhada para o WhatsApp!
                  </h3>
                  <p className="text-sm text-[#D4D0C7] max-w-md mx-auto">
                    Caso a conversa não tenha aberto automaticamente, clique no botão abaixo para conversar agora mesmo com nossa equipe.
                  </p>
                  <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
                    <a
                      href={generatedUrl || getWhatsAppUrl()}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="gold-cta-btn px-6 py-3 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-2"
                    >
                      <MessageSquare className="w-4 h-4 text-[#0A0A0A]" />
                      <span>Abrir WhatsApp Novamente</span>
                    </a>
                    <button
                      type="button"
                      onClick={() => setSubmitted(false)}
                      className="text-xs text-[#8F8C84] hover:text-white underline p-2 cursor-pointer"
                    >
                      Preencher outro formulário
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="border-b border-white/10 pb-4 mb-2">
                    <h3 className="text-xl font-bold text-white font-display">
                      Calculadora & Proposta Express
                    </h3>
                    <p className="text-xs text-[#8F8C84] mt-1">
                      Leva menos de 1 minuto. Receba a proposta detalhada direto no seu WhatsApp.
                    </p>
                  </div>

                  {/* Name and WhatsApp row */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-[#D4D0C7] mb-1.5">
                        Seu Nome ou Empresa *
                      </label>
                      <input
                        type="text"
                        name="name"
                        required
                        value={formState.name}
                        onChange={handleInputChange}
                        placeholder="Ex: Dra. Ana Paula ou TechSolutions"
                        className="w-full px-4 py-3 rounded-xl bg-[#0F0F13] border border-white/10 text-white text-sm focus:outline-none focus:border-[#D4AF37] transition-colors"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-[#D4D0C7] mb-1.5">
                        WhatsApp com DDD *
                      </label>
                      <input
                        type="tel"
                        name="whatsapp"
                        required
                        value={formState.whatsapp}
                        onChange={handleInputChange}
                        placeholder="Ex: (21) 98956-4215"
                        className="w-full px-4 py-3 rounded-xl bg-[#0F0F13] border border-white/10 text-white text-sm focus:outline-none focus:border-[#D4AF37] transition-colors"
                      />
                    </div>
                  </div>

                  {/* Business Type and Service Type */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-[#D4D0C7] mb-1.5">
                        Ramo / Segmento
                      </label>
                      <input
                        type="text"
                        name="businessType"
                        value={formState.businessType}
                        onChange={handleInputChange}
                        placeholder="Ex: Clínica, Advocacia, Imobiliária, E-commerce..."
                        className="w-full px-4 py-3 rounded-xl bg-[#0F0F13] border border-white/10 text-white text-sm focus:outline-none focus:border-[#D4AF37] transition-colors"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-[#D4D0C7] mb-1.5">
                        Tipo de Site Desejado
                      </label>
                      <select
                        name="serviceType"
                        value={formState.serviceType}
                        onChange={handleInputChange}
                        className="w-full px-4 py-3 rounded-xl bg-[#0F0F13] border border-white/10 text-white text-sm focus:outline-none focus:border-[#D4AF37] transition-colors"
                      >
                        <option value="Landing Page de Alta Conversão">Landing Page de Alta Conversão</option>
                        <option value="Site Institucional Corporativo">Site Institucional Corporativo</option>
                        <option value="Site Express no Mesmo Dia (24h)">Site Express no Mesmo Dia (24h)</option>
                        <option value="E-commerce / Loja Virtual">E-commerce / Loja Virtual</option>
                        <option value="Redesign / Modernização de Site Existente">Redesign / Modernização de Site Existente</option>
                        <option value="Outro / Preciso de Orientação">Outro / Preciso de Orientação</option>
                      </select>
                    </div>
                  </div>

                  {/* Urgency / Prazo */}
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-[#D4D0C7] mb-1.5">
                      Qual é o seu prazo de lançamento?
                    </label>
                    <select
                      name="urgency"
                      value={formState.urgency}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 rounded-xl bg-[#0F0F13] border border-white/10 text-white text-sm focus:outline-none focus:border-[#D4AF37] transition-colors"
                    >
                      <option value="Urgência máxima · Quero entrega no mesmo dia (24h)">
                        ⚡ Urgência máxima · Quero entrega no mesmo dia (24h)
                      </option>
                      <option value="Para os próximos dias (3 a 5 dias)">
                        Para os próximos dias (3 a 5 dias)
                      </option>
                      <option value="Planejando para este mês">
                        Planejando para este mês
                      </option>
                      <option value="Apenas pesquisando valores no momento">
                        Apenas pesquisando valores no momento
                      </option>
                    </select>
                  </div>

                  {/* Additional notes */}
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-[#D4D0C7] mb-1.5">
                      Conte um pouco sobre o objetivo do site (opcional)
                    </label>
                    <textarea
                      name="message"
                      rows={3}
                      value={formState.message}
                      onChange={handleInputChange}
                      placeholder="Ex: Queremos vender mais consultas particulares e substituir um site antigo feito no Wix..."
                      className="w-full px-4 py-3 rounded-xl bg-[#0F0F13] border border-white/10 text-white text-sm focus:outline-none focus:border-[#D4AF37] transition-colors resize-none"
                    />
                  </div>

                  {/* Submit Button */}
                  <div className="pt-2">
                    <button
                      type="submit"
                      className="gold-cta-btn w-full py-4 rounded-xl text-sm font-extrabold uppercase tracking-wider flex items-center justify-center gap-3 cursor-pointer shadow-xl group"
                    >
                      <MessageSquare className="w-5 h-5 text-[#0A0A0A]" />
                      <span>Solicitar Orçamento no WhatsApp</span>
                      <Send className="w-4 h-4 text-[#0A0A0A] group-hover:translate-x-1 transition-transform" />
                    </button>
                    <p className="text-[11px] text-center text-[#8F8C84] mt-2.5">
                      Ao clicar, sua solicitação será enviada formatada diretamente para o nosso WhatsApp oficial.
                    </p>
                  </div>
                </form>
              )}

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
