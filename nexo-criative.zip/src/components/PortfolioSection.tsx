import React, { useState } from 'react';
import { PORTFOLIO, getWhatsAppUrl } from '../data/agencyData.ts';
import { PortfolioItem } from '../types.ts';
import { ExternalLink, Check, Sparkles, MessageSquare, X, ArrowUpRight } from 'lucide-react';

export const PortfolioSection: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<string>('Todos');
  const [selectedProject, setSelectedProject] = useState<PortfolioItem | null>(null);

  const categories = ['Todos', 'Institucional', 'Landing Page', 'Express 24h'];

  const filteredProjects =
    activeCategory === 'Todos'
      ? PORTFOLIO
      : PORTFOLIO.filter((p) => p.category === activeCategory);

  return (
    <section id="portfolio" className="py-24 bg-[#0A0A0A] relative border-t border-[var(--border-subtle)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header with Category Filter */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-16">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 text-xs font-bold tracking-widest uppercase text-[#D4AF37] mb-3">
              <span>03 · Casos de Sucesso</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight font-display">
              Projetos que transmitem <span className="gold-text-gradient">autoridade</span> imediata.
            </h2>
            <p className="text-base text-[#D4D0C7] mt-3">
              Cada projeto é desenvolvido do zero, respeitando a identidade única de cada marca e estruturado para converter visitantes em clientes.
            </p>
          </div>

          {/* Category Filter Controls */}
          <div className="flex flex-wrap items-center gap-2 p-1.5 rounded-xl bg-[#141419] border border-white/5 w-fit">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                  activeCategory === cat
                    ? 'bg-[#D4AF37] text-[#0A0A0A] shadow-md font-bold'
                    : 'text-[#D4D0C7] hover:text-white hover:bg-white/5'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {filteredProjects.map((project) => (
            <div
              key={project.id}
              className="group rounded-2xl overflow-hidden bg-[#121217] border border-[var(--border-subtle)] hover:border-[var(--border-gold)]/60 transition-all duration-500 shadow-xl flex flex-col justify-between"
            >
              {/* Image Preview with browser-like frame */}
              <div className="relative overflow-hidden bg-[#0F0F13]">
                {/* Metric pill */}
                <div className="absolute top-4 left-4 z-10 px-3.5 py-1.5 rounded-lg bg-[#0A0A0A]/90 backdrop-blur-md border border-[var(--border-gold)]/50 text-xs font-bold text-[#F3E5AB] flex items-center gap-1.5 shadow-lg">
                  <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>{project.metric} {project.metricLabel}</span>
                </div>

                {/* Category badge */}
                <div className="absolute top-4 right-4 z-10 px-3 py-1 rounded-md bg-[#1C1C24]/85 text-[11px] font-semibold text-[#D4D0C7] border border-white/10">
                  {project.category}
                </div>

                <div className="aspect-[16/10] overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
                    loading="lazy"
                    referrerPolicy="no-referrer"
                  />
                </div>

                {/* Subtle scrim overlay on hover */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0A] via-transparent to-transparent opacity-60" />
              </div>

              {/* Project Info */}
              <div className="p-6 sm:p-8 flex-1 flex flex-col justify-between space-y-4">
                <div>
                  <div className="text-xs uppercase tracking-wider text-[#8F8C84] font-semibold">
                    {project.client}
                  </div>
                  <h3 className="text-xl sm:text-2xl font-bold text-white mt-1 font-display group-hover:text-[#F3E5AB] transition-colors">
                    {project.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-[#A3A3A8] mt-2 line-clamp-2 leading-relaxed">
                    {project.description}
                  </p>
                </div>

                {/* Tags */}
                <div className="flex flex-wrap gap-2 pt-2">
                  {project.technologies.map((tech, idx) => (
                    <span
                      key={idx}
                      className="text-[11px] px-2.5 py-1 rounded-md bg-[#171720] text-[#D4D0C7] border border-white/5"
                    >
                      {tech}
                    </span>
                  ))}
                </div>

                {/* Actions */}
                <div className="pt-4 border-t border-white/10 flex items-center justify-between gap-4">
                  <button
                    onClick={() => setSelectedProject(project)}
                    className="text-xs font-bold text-[#D4AF37] hover:text-[#F3E5AB] flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <span>Ver detalhes do projeto</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>

                  <a
                    href={getWhatsAppUrl(`Olá Nexo Criative! Adorei o projeto "${project.title}" do portfólio. Gostaria de um orçamento para um site parecido.`)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="gold-outline-btn px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-1.5"
                  >
                    <MessageSquare className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>Quero um assim</span>
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Modal for Project Deep-Dive */}
        {selectedProject && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
            <div className="bg-[#121217] border border-[var(--border-gold)] rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl relative">
              {/* Close button */}
              <button
                onClick={() => setSelectedProject(null)}
                className="absolute top-4 right-4 z-20 p-2 rounded-full bg-[#0A0A0A]/80 text-[#D4D0C7] hover:text-white border border-white/10"
                aria-label="Fechar detalhes"
              >
                <X className="w-5 h-5" />
              </button>

              {/* Large Image Preview */}
              <div className="relative aspect-video w-full overflow-hidden bg-black">
                <img
                  src={selectedProject.image}
                  alt={selectedProject.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-4 left-4 px-3.5 py-1.5 rounded-lg bg-[#0A0A0A]/90 border border-[var(--border-gold)]/60 text-xs font-bold text-[#F3E5AB]">
                  Resultado: {selectedProject.metric} {selectedProject.metricLabel}
                </div>
              </div>

              {/* Content */}
              <div className="p-6 sm:p-8 space-y-6">
                <div>
                  <div className="text-xs uppercase tracking-wider text-[#D4AF37] font-semibold">
                    {selectedProject.client} · {selectedProject.category}
                  </div>
                  <h3 className="text-2xl sm:text-3xl font-extrabold text-white mt-1 font-display">
                    {selectedProject.title}
                  </h3>
                  <p className="text-sm sm:text-base text-[#D4D0C7] mt-3 leading-relaxed">
                    {selectedProject.description}
                  </p>
                </div>

                {/* Features highlighted */}
                <div className="space-y-3">
                  <h4 className="text-xs uppercase tracking-wider font-bold text-[#8F8C84]">
                    Recursos implementados neste projeto:
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {selectedProject.features.map((feat, i) => (
                      <div key={i} className="flex items-center gap-2 text-xs sm:text-sm text-[#FAF8F5]">
                        <Check className="w-4 h-4 text-[#D4AF37] shrink-0" />
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Call to action inside modal */}
                <div className="pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div className="text-xs text-[#8F8C84]">
                    Precisa de um resultado semelhante para a sua empresa?
                  </div>
                  <a
                    href={getWhatsAppUrl(`Olá Nexo Criative! Vi os detalhes do projeto "${selectedProject.title}" e quero um orçamento para a minha empresa.`)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="gold-cta-btn px-6 py-3 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-2 w-full sm:w-auto justify-center"
                  >
                    <MessageSquare className="w-4 h-4 text-[#0A0A0A]" />
                    <span>Quero um site neste padrão</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        )}

      </div>
    </section>
  );
};
