export interface ServiceItem {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  deliverables: string[];
  deliveryTime: string;
  isPopular?: boolean;
  idealFor: string;
  whatsappPreset: string;
}

export interface PortfolioItem {
  id: string;
  title: string;
  client: string;
  category: 'Landing Page' | 'Institucional' | 'E-commerce' | 'Express 24h';
  image: string;
  metric: string;
  metricLabel: string;
  description: string;
  technologies: string[];
  features: string[];
}

export interface TestimonialItem {
  id: string;
  name: string;
  role: string;
  company: string;
  city: string;
  avatar: string;
  content: string;
  metric: string;
  serviceUsed: string;
}

export interface FaqItem {
  question: string;
  answer: string;
}
