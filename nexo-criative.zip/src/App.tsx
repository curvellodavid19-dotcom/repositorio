import React from 'react';
import { Navbar } from './components/Navbar.tsx';
import { HeroSection } from './components/HeroSection.tsx';
import { AboutSection } from './components/AboutSection.tsx';
import { ServicesSection } from './components/ServicesSection.tsx';
import { RoiSimulator } from './components/RoiSimulator.tsx';
import { PortfolioSection } from './components/PortfolioSection.tsx';
import { TestimonialsSection } from './components/TestimonialsSection.tsx';
import { ContactSection } from './components/ContactSection.tsx';
import { Footer } from './components/Footer.tsx';
import { FloatingWhatsApp } from './components/FloatingWhatsApp.tsx';

export default function App() {
  return (
    <div className="min-h-screen bg-[#0A0A0A] text-[#FAF8F5] flex flex-col selection:bg-[#D4AF37]/30 selection:text-white">
      {/* Top Bar Header */}
      <Navbar />

      {/* Main Content Sections (Strict Order as Requested) */}
      <main className="flex-1">
        {/* 1. Seção inicial impactante */}
        <HeroSection />

        {/* 2. Sobre / Quem sou */}
        <AboutSection />

        {/* 3. Serviços (Criação de sites) */}
        <ServicesSection />

        {/* Simulador Interativo de Faturamento / Perda de Clientes para Concorrentes */}
        <RoiSimulator />

        {/* 4. Portfólio / Projetos */}
        <PortfolioSection />

        {/* 5. Depoimentos */}
        <TestimonialsSection />

        {/* 6. Formulário de contato */}
        <ContactSection />
      </main>

      {/* Footer */}
      <Footer />

      {/* 7. WhatsApp flutuante */}
      <FloatingWhatsApp />
    </div>
  );
}
